import React from "react";
import { useAuth } from "../context/AuthContext";


const Main = () => {
    const { currentUser } = useAuth();

    return (
        <div className="py-4 w-full min-h-screen flex flex-col justify-start items-center">
            {/* user info from firebase */}
            <div className="m-1">
                {currentUser ? (
                    <div className="w-full flex flex-col justify-center">
                        <h1 className="text-base text-white text-center font-bold">Welcome!</h1>
                        <br />
                        <br />
                        <br />
                        <h1 className="text-base text-white text-center font-bold">Name: {currentUser.displayName}</h1>
                        <h1 className="text-base text-white text-center font-bold">Email: {currentUser.email}</h1>
                    </div>
                ) : (
                    <h1 className="text-base text-white text-center font-bold">No User Logged in!</h1>
                )}
            </div>
        </div>
    );
};

export default Main;
