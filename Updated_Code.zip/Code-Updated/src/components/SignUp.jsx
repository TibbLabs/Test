import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { auth } from "../firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const SignUp = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();

    const { user } = useAuth();

    const resetMessages = () => {
        setError("");
        setSuccess("");
    };

    const validateForm = () => {
        if (!email) {
            setError("Please enter email address.");
            setLoading(false);
            return false;
        }
        if (!password) {
            setError("Please enter password.");
            setLoading(false);
            return false;
        }
        if (!confirmPassword) {
            setError("Please re-enter password to confirm.");
            setLoading(false);
            return false;
        }
        if (!email.includes("@")) {
            setError("Please enter a valid email address.");
            setLoading(false);
            return false;
        }
        if (password.length < 6) {
            setError("Password must be at least 6 characters long.");
            setLoading(false);
            return false;
        }
        return true;
    };

    const handleSignup = async (e) => {
        e.preventDefault();
        resetMessages();
        setLoading(true);

        if (!validateForm()) return;

        // setError("Passwords donot match");
        if (confirmPassword === password) {
            try {
                setError("");
                setSuccess("");
                // Firebase signup
                const userCredential = await createUserWithEmailAndPassword(
                    auth,
                    email,
                    password
                );
                console.log("userCredential.user: ", userCredential.user);
                setSuccess(
                    "Signup successful! Welcome, " + userCredential.user.email
                );
                setLoading(false);
                navigate("/main");
            } catch (err) {
                // setError(err.message);
                // setLoading(false);

                if (err.message === "Firebase: Error (auth/invalid-email).") {
                    setError("No Email or password");
                } else if (
                    err.message === "Firebase: Error (auth/invalid-credential)."
                ) {
                    setError("Invalid Credentials");
                } else {
                    setError("Server Error");
                }

                setLoading(false);
            }
        } else {
            setError("Passwords donot match");
            console.log("Passwords donot match");
            setLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        resetMessages();
        setLoading(true);

        if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
            chrome.runtime.sendMessage(
                { type: "firebase-auth", target: "offscreen" },
                (response) => {
                    if (chrome.runtime.lastError) {
                        console.error("Error 1 : ", chrome.runtime.lastError);
                        setLoading(false);
                    } else if (response.error) {
                        console.error(
                            "Error 2 : Error during authentication:",
                            response.error
                        );
                        setLoading(false);
                    } else {
                        console.log(
                            "User authenticated successfully:",
                            response
                        );
                        setLoading(false);
                        // Handle the user object in response
                    }
                }
            );
        } else {
            console.error(
                "Chrome API is not available. Are you running in a Chrome extension environment?"
            );
            
            setLoading(false);
        }
    };

    useEffect(() => {
        if (user) {
            console.log("User Found!");
        } else {
            console.log("No User Found!");
        }
    }, [user]);

    return (
        <div className="w-full h-full flex flex-col justify-between items-center min">
            <div className="w-full flex justify-end fixed m-[-50px]">
                {(error || success) && (
                    <p className="text-sm font-semibold w-[250px] bg-white p-2 rounded-l-full animate-slideInFromRight">
                        {error && <p className="text-red-500">{error}</p>}
                        {success && <p className="text-green-500">{success}</p>}
                    </p>
                )}
            </div>
            <div className="flex flex-col w-full h-full items-center justify-center p-6">
                {/* Header */}
                <h2 className="text-2xl font-bold text-white mb-6">SignUp</h2>

                {/* Form */}
                <form
                    onSubmit={handleSignup}
                    className="w-full flex flex-col items-center justify-center max-w-sm space-y-4"
                >
                    {/* Email Input */}
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-4 py-2 rounded-full bg-white placeholder-gray-400 text-black focus:outline-none"
                    />

                    {/* Password Input */}
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-2 rounded-full bg-white placeholder-gray-400 text-black focus:outline-none"
                    />

                    {/* Confirm Password Input */}
                    <input
                        type="password"
                        placeholder="Confirm Password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full px-4 py-2 rounded-full bg-white placeholder-gray-400 text-black focus:outline-none"
                    />

                    {/* Login Button */}
                    <button
                        type="submit"
                        // onClick={handleSignup}
                        disabled={loading}
                        className={`w-full py-2 mt-4 text-white bg-gradient-to-r from-gradient-start to-gradient-end rounded-full ${
                            loading ? "opacity-50 py-4" : ""
                        }`}
                    >
                        {loading ? "Signing Up..." : "Sign Up"}
                    </button>
                </form>

                <div className="w-full max-w-sm flex items-center space-x-2 my-4">
                    <span className="flex-grow h-px bg-gray-300 opacity-40"></span>
                    <span className="text-gray-200 font-semibold">OR</span>
                    <span className="flex-grow h-px bg-gray-300 opacity-40"></span>
                </div>

                <div className="w-full max-w-sm flex justify-center">
                    <button
                        onClick={handleGoogleSignIn}
                        // onClick={handleGoogleSignIn2}
                        className="w-full py-2 text-white bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center space-x-2"
                    >
                        <span>Sign Up with Google</span>
                    </button>
                </div>

                {/* Sign-up Link */}
                <p className="mt-4 text-sm text-gray-200">
                    Already have an Account?{" "}
                    <Link to="/login">
                        <span className="font-semibold hover:underline cursor-pointer">
                            Login now!
                        </span>
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default SignUp;
