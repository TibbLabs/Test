import React from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from "../firebaseConfig";
import { signOut } from "firebase/auth";
import { useAuth } from "../context/AuthContext";

const Header = () => {
    const navigate = useNavigate();
    const { currentUser } = useAuth();

    const logout = async () => {
        try {
            await signOut(auth);
            // console.log("User signed out successfully");
            navigate("/login"); // Redirect to login page after logout
        } catch (error) {
            console.error("Error during sign out: ", error);
        }
    };

    return (
        <div className='flex flex-row items-center justify-between h-12'>
            {currentUser && 
                <div className='flex flex-row items-center space-x-4'>
                    <div>
                        <h1 className='text-white hover:underline cursor-pointer' onClick={logout}>Logout</h1>
                    </div>
                </div>
            }
        </div>
    );
};

export default Header;
