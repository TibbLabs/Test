import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { auth, signInWithGoogle } from "../firebaseConfig";
import { signInWithEmailAndPassword } from "firebase/auth";
import { useAuth } from "../context/AuthContext";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();
    const { currentUser } = useAuth();

    useEffect(() => {
        if (currentUser) {
            // Redirect if the user is already logged in
            navigate("/main");
        }
    }, [currentUser, navigate]);

    const resetMessages = () => {
        setError("");
        setSuccess("");
    };

    const validateForm = () => {
        if (!email) {
            setError("Please enter email address.");
            setLoading(false);
            return false;
        }
        if (!password) {
            setError("Please enter password.");
            setLoading(false);
            return false;
        }
        if (!email.includes("@")) {
            setError("Please enter a valid email address.");
            setLoading(false);
            return false;
        }
        return true;
    };

    const handleEmailLogin = async (e) => {
        resetMessages();
        e.preventDefault();
        setLoading(true);

        if (!validateForm()) return;

        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            console.log("Logged in user: ", userCredential.user);
            setLoading(false);
            setSuccess("Login successful! Welcome, " + userCredential.user.email);
            navigate("/main"); // Redirect after successful login
        } catch (err) {
            if (err.message === "Firebase: Error (auth/invalid-email).") {
                setError("Invalid Email or password")
            }
            else if (err.message === "Firebase: Error (auth/invalid-credential).") {
                setError("Invalid Credentials");
            }
            else {
                setError("Server Error");
            }

            setLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        resetMessages();
        setLoading(true);

        try {
            const result = await signInWithGoogle();
            const user = result.user;
            setSuccess(`Google Sign-In User: ${user.displayName}`);
            console.log("Google Sign-In User: ", user);
            console.log("Display Name: ", user.displayName);
            setLoading(false);
            navigate("/main"); // Redirect after successful login
        } catch (err) {
            setError(err.message);
            setLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col justify-between items-center min">
            <div className="w-full flex justify-end fixed m-[-50px]">
                { (error || success) && 
                    <div className="text-sm font-semibold bg-white p-2 rounded-l-full animate-slideInFromRight">
                        {error && <p className="text-red-500">{error}</p>}
                        {success && <p className="text-green-500">{success}</p>}
                    </div>
                }
            </div>
            <div className="flex flex-col w-full h-full items-center justify-center p-6">
                <h2 className="text-2xl font-bold text-white mb-6">Login</h2>
                
                {/* Form */}
                <form onSubmit={handleEmailLogin} className="w-full flex flex-col items-center justify-center max-w-sm space-y-4">
                    {/* Email Input */}
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-4 py-2 rounded-full bg-white placeholder-gray-400 text-black focus:outline-none"
                    />
    
                    {/* Password Input */}
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-2 rounded-full bg-white placeholder-gray-400 text-black focus:outline-none"
                    />
    
                    {/* Login Button */}
                    <button
                        type="submit"
                        disabled={loading}
                        className={`w-full py-2 mt-4 text-white bg-gradient-to-r from-gradient-start to-gradient-end rounded-full ${ loading ? "opacity-50" : "" }`}
                    >
                        {loading ? "Logging In..." : "Login"}
                    </button>
                </form>

                <div className="w-full max-w-sm flex items-center space-x-2 my-4">
                    <span className="flex-grow h-px bg-gray-300 opacity-40"></span>
                    <span className="text-gray-500">OR</span>
                    <span className="flex-grow h-px bg-gray-300 opacity-40"></span>
                </div>

                {/* Google Sign-In Button */}
                <div className="w-full max-w-sm flex justify-center">
                    <button
                        onClick={handleGoogleSignIn}
                        disabled={loading}
                        className={`w-full py-2 text-white bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center space-x-2 ${
                            loading ? "opacity-50" : ""
                        }`}
                    >
                        <span>{loading ? "Signing In..." : "Sign In with Google"}</span>
                    </button>
                </div>
    
                {/* Sign-up Link */}
                <p className="mt-4 text-sm text-gray-200">
                    Don’t have an Account?{" "}
                    <Link to="/sign-up">
                        <span className="font-semibold hover:underline cursor-pointer">
                            Sign up now!
                        </span>
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default Login;
