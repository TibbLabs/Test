
import Login from "./components/Login";
import { HashRouter as Router, Route, Routes } from "react-router-dom";
import SignUp from "./components/SignUp";
import Main from "./components/main";
import Header from "./components/Header";

function App() {
    return (
        <div className="p-4 bg-custom-circular-gradient min-h-screen flex overflow-y-scroll h-64 custom-scrollbar">
            <main className="flex-grow">
                <div className="flex flex-col">
                    <Router>
                        <Header />
                        <div className="">
                            <div className="flex flex-col items-center justify-between">
                                <Routes>
                                    <Route path="/" element={<Login />} />
                                    <Route path="/login" element={<Login />} />
                                    <Route path="/sign-up" element={<SignUp />} />
                                    <Route path="/main" element={<Main />} />
                                </Routes>
                            </div>
                        </div>
                    </Router>
                </div>
            </main>
        </div>
    );
}

export default App;
