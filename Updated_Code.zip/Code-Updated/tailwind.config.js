/** @type {import('tailwindcss').Config} */
export const content = [
  "./src/**/*.{js,jsx,ts,tsx}",
];
export const theme = {
  extend: {
    backgroundImage: {
      'custom-circular-gradient': 'radial-gradient(circle, #a20000 0%, #620000 100%)',
    },
    colors: {
      'gradient-start': '#710c1e',
      'gradient-start2': '#a20000',
      'gradient-middle1': '#660f20',
      'gradient-middle2': '#4b1721',
      'gradient-end': '#3e1a21',
    },
    keyframes: {
      slideInFromRight: {
        '0%': { transform: 'translateX(100%)', opacity: 0 },
        '100%': { transform: 'translateX(0)', opacity: 1 },
      },
    },
    animation: {
      slideInFromRight: 'slideInFromRight 1.5s ease-out forwards',
    },
  },
};
export const plugins = [];
