import { signInWithPopup, GoogleAuthProvider } from'firebase/auth';
import { auth } from '../src/firebaseConfig.js';

// This code runs inside of an iframe in the extension's offscreen document.
// This gives you a reference to the parent frame, i.e. the offscreen document.
// You will need this to assign the targetOrigin for postMessage.
const PARENT_FRAME = document.location.ancestorOrigins[0];

// This demo uses the Google auth provider, but any supported provider works.
// Make sure that you enable any provider you want to use in the Firebase Console.
// https://console.firebase.google.com/project/_/authentication/providers
const PROVIDER = new GoogleAuthProvider();

window.addEventListener("message", async (event) => {
  if (event.data.initAuth) {
      try {
          const result = await signInWithPopup(auth, PROVIDER);
          const user = result.user;
          // Send the user data back to the offscreen document
          window.parent.postMessage(JSON.stringify(user), event.origin);
      } catch (error) {
          window.parent.postMessage(JSON.stringify({ error: error.message }), event.origin);
      }
  }
});