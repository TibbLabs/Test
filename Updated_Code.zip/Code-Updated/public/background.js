chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed");
});

const OFFSCREEN_DOCUMENT_PATH = "./offscreen.html";

// A global promise to avoid concurrency issues
let creatingOffscreenDocument = null; // Prevent concurrent creation
let offscreenDocumentActive = false; // Global flag to track document status

// Chrome only allows for a single offscreenDocument. This is a helper function
// that returns a boolean indicating if a document is already active.
async function hasDocument() {
    // Check all windows controlled by the service worker to see if one
    // of them is the offscreen document with the given path
    const matchedClients = await clients.matchAll();
    return matchedClients.some(
        (c) => c.url === chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)
    );
}

async function hasOffscreenDocument() {
    const matchedClients = await clients.matchAll();
    return matchedClients.some(
        (client) => client.url === chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)
    );
}

// Function to create an offscreen document
async function setupOffscreenDocument() {
    if (offscreenDocumentActive) {
        console.log("Offscreen document already exists.");
        return;
    }

    if (creatingOffscreenDocument) {
        await creatingOffscreenDocument; // Wait if another creation is in progress
        return;
    }

    try {
        console.log("Creating offscreen document...");
        creatingOffscreenDocument = chrome.offscreen.createDocument({
            url: OFFSCREEN_DOCUMENT_PATH,
            reasons: [chrome.offscreen.Reason.DOM_SCRAPING],
            justification: "Needed for Firebase authentication.",
        });
        await creatingOffscreenDocument;
        offscreenDocumentActive = true; // Mark as active
        console.log("Offscreen document created.");
    } catch (err) {
        console.error("Failed to create offscreen document:", err);
    } finally {
        creatingOffscreenDocument = null; // Reset the promise
    }
}

// Function to close the offscreen document
async function closeOffscreenDocument() {
    if (!offscreenDocumentActive) {
        console.log("No active offscreen document to close.");
        return;
    }

    try {
        console.log("Closing offscreen document...");
        await chrome.offscreen.closeDocument();
        offscreenDocumentActive = false; // Mark as inactive
        console.log("Offscreen document closed.");
    } catch (err) {
        console.error("Failed to close offscreen document:", err);
    }
}

function getAuth() {
    return new Promise(async (resolve, reject) => {
        try {
            console.log("Waiting for auth....");

            const auth = await chrome.runtime.sendMessage({
                type: "firebase-auth",
                target: "offscreen",
            });

            console("Got auth => ", auth);

            auth?.name !== "FirebaseError" ? resolve(auth) : reject(auth);
        } catch (err) {
            reject(err);
        }
    });
}

// Main Firebase Authentication Handler
async function firebaseAuth() {
    await setupOffscreenDocument();

    try {
        const auth = await getAuth();
        console.log("User Authenticated => ", auth);
        return auth;
    } catch (err) {
        console.error("Authentication error => ", err);
        return err;
    } finally {
        await closeOffscreenDocument(); // Cleanup after authentication
    }
}

// Message listener for Firebase authentication
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.type === "firebase-auth" && message.target === "offscreen") {
        console.log("Received authentication request.");

        try {
            await setupOffscreenDocument();
            console.log("making auth request");
            
            const auth = await getAuth();

            console.log("Auth success => ", auth);

            sendResponse(auth);
        } catch (error) {
            console.error("Error during authentication:", error);
            sendResponse({ error: error.message });
        } finally {
            await closeOffscreenDocument();
        }

        return true; // Keep async channel open
    }
});
